
export interface Users {
  id: string;
  username: string;
  password: string;
  email: string;
  rut: string;
  isactive: boolean;
  justificaciones: any[]; // Puedes definir una interfaz específica si lo deseas
  clasesRegistradas: any[]; // Igual aquí, si es necesario
}

export interface UserNuevo {
    id: string;
    username: string;
    password: string;
    email: string;
    rut: string;
    isactive: boolean;
    justificaciones: any[]; // Puedes definir una interfaz específica si lo deseas
    clasesRegistradas: any[];// Un array vacío para las clases registradas
  }
  


