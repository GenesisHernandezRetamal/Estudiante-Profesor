import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-cambiar-contra',
  templateUrl: './cambiar-contra.page.html',
  styleUrls: ['./cambiar-contra.page.scss'],
})
export class CambiarContraPage implements OnInit {
  email:string="";

  ngOnInit() {
  }
  limpiar(){
    this.email="";
    }
}
