import { Component, OnInit } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-asistencia',
  templateUrl: './asistencia.page.html',
  styleUrls: ['./asistencia.page.scss'],
})
export class AsistenciaPage implements OnInit {

  nombre: string = '';
  asignatura: string = '';
  fechaInasistencia: string = '';
  motivo: string = '';
  profesor: string='';
  justificativo: string='';

  constructor(private alertController: AlertController, private router: Router) { }

  ngOnInit() { }

  async enviarJustificacion() {
    const alert = await this.alertController.create({
      header: 'Justificación Enviada',
      message: `Nombre: ${this.nombre}  Asignatura: ${this.asignatura} Fecha: ${this.fechaInasistencia} Motivo: ${this.motivo} Profesor:${this.profesor}
      Justificativo: ${this.justificativo}`,
      buttons: [
        {
          text: 'OK',
          role: 'confirm',
          handler: () => {
            this.limpiarFormulario();
            this.router.navigate(['/inicio']); 
          },
        },
      ],
    });
    await alert.present();
  }

  limpiarFormulario() {
    this.nombre = '';
    this.asignatura = '';
    this.fechaInasistencia = '';
    this.motivo = '';
    this.profesor='';
    this.justificativo='';
  }
}