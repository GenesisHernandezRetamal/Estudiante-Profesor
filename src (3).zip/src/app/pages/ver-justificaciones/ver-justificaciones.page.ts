import { Component, OnInit } from '@angular/core';
import { ApicrudService } from 'src/app/services/apicrud.service'; // Asegúrate de que esta ruta sea correcta
import { Router } from '@angular/router';

@Component({
  selector: 'app-ver-justificaciones',
  templateUrl: './ver-justificaciones.page.html',
  styleUrls: ['./ver-justificaciones.page.scss'],
})
export class VerJustificacionesPage implements OnInit {
  
  justificaciones: any[] = [];  // Para almacenar las justificaciones del usuario logueado
  usuario: any;  // Usuario logueado

  constructor(private apiCrud: ApicrudService, private router: Router) { }

  ngOnInit() {
    // Obtener el usuario logueado
    const usuarioLogueado = JSON.parse(sessionStorage.getItem('currentUser') || '{}');
    if (usuarioLogueado && usuarioLogueado.id) {
      this.usuario = usuarioLogueado;
      // Obtener las justificaciones del usuario logueado
      this.apiCrud.getJustificacionesDeUsuario(this.usuario.id).subscribe((justificaciones) => {
        this.justificaciones = justificaciones;
        console.log('Justificaciones del usuario:', this.justificaciones);
      }, (error) => {
        console.error('Error al cargar las justificaciones', error);
      });
    } else {
      // Redirigir al login si el usuario no está logueado
      this.router.navigate(['/login']);
    }
  }
}
