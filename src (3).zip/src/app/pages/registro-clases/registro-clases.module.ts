import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { QRCodeModule } from 'angularx-qrcode';
import { IonicModule } from '@ionic/angular';

import { RegistroClasesPageRoutingModule } from './registro-clases-routing.module';

import { RegistroClasesPage } from './registro-clases.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    QRCodeModule,
    IonicModule,
    RegistroClasesPageRoutingModule
  ],
  declarations: [RegistroClasesPage]
})
export class RegistroClasesPageModule {}
