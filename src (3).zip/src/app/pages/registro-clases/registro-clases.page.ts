import { Component, OnInit } from '@angular/core';
import { AuthserviceService } from 'src/app/services/auth.service';
import { Users } from 'src/interfaces/users';

@Component({
  selector: 'app-registro-clases',
  templateUrl: './registro-clases.page.html',
  styleUrls: ['./registro-clases.page.scss'],
})
export class RegistroClasesPage implements OnInit {

  usuario: Users | null = null;
  clasesRegistradas: any[] = [];
  qrData: string | null = null;

  constructor(private authService: AuthserviceService) { }

  ngOnInit(): void {
    const username = sessionStorage.getItem('username');
    
    if (username) {
      this.authService.GetUserByUsername(username).subscribe(
        (usuarios) => {
          const usuarioLogueado = usuarios.find(u => u.username === username);
          if (usuarioLogueado) {
            this.usuario = usuarioLogueado;
            this.clasesRegistradas = usuarioLogueado.clasesRegistradas;
          }
        },
        (error) => {
          console.error('Error al obtener el usuario:', error);
        }
      );
    }
  }

  // Función para generar el QR de una asignatura
  generarQR(clase: any): void {
    // Mostrar los datos de la clase en la consola
    console.log('Datos de la clase seleccionada:', clase);
    console.log('Datos del usuario logueado:', this.usuario);

    // Generar el QR con la información
    this.qrData = `${clase.nombre} ${clase.profesor} ${this.usuario?.email} ${this.usuario?.rut}`;

    // Guardar el QR en la clase correspondiente
    this.guardarQR(clase);
  }

  // Función para guardar el QR generado en las clases registradas
  guardarQR(clase: any): void {
    // Encontrar la clase en las clasesRegistradas y agregar el QR
    const claseIndex = this.clasesRegistradas.findIndex(c => c.idAsignatura === clase.idAsignatura);
    if (claseIndex !== -1) {
      this.clasesRegistradas[claseIndex].qrData = this.qrData;
      
      // Actualizar el usuario con la clase modificada
      if (this.usuario) {
        this.usuario.clasesRegistradas = this.clasesRegistradas;
        // Aquí puedes hacer la actualización en la base de datos o en tu servicio de API
        this.authService.updateUser(this.usuario).subscribe(
          (response) => {
            console.log('Usuario actualizado con el QR');
          },
          (error) => {
            console.error('Error al actualizar usuario:', error);
          }
        );
      }
    }
  }
}
