import { Component, OnInit } from '@angular/core';
import { ApidatosService } from 'src/app/services/apidatos.service';
import { NavController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-asignaturas',
  templateUrl: './asignaturas.page.html',
  styleUrls: ['./asignaturas.page.scss'],
  
})
export class AsignaturasPage implements OnInit {
  asignaturas: any[] = [];

  constructor(private apidatosService: ApidatosService, private navCtrl: NavController, private router: Router) {
  }


  ngOnInit() {
    this.apidatosService.getAsignaturas().subscribe(data => {
      this.asignaturas = data; 
    });
  }
  

  irInicio() {
    this.navCtrl.navigateRoot('/inicio');
  }
  
  buscarPost(asignatura: any) {
    this.router.navigate(['/detalle'], { queryParams: { post: JSON.stringify(asignatura) } });
  }


 
}