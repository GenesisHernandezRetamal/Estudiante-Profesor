import { Component, OnInit } from '@angular/core';
import { ApicrudService } from 'src/app/services/apicrud.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-justificacion',
  templateUrl: './justificacion.page.html',
  styleUrls: ['./justificacion.page.scss'],
})
export class JustificacionPage implements OnInit {

  asignaturaSeleccionada: string = ''; 
  profesorSeleccionado: string = '';    
  fechaJustificacion: string = '';      
  motivoJustificacion: string = '';     

  asignaturas: any[] = [];
  profesores: any[] = [];
  usuario: any;  

  constructor(private apiCrud: ApicrudService, private router: Router) { }

  ngOnInit() {
    const usuarioLogueado = JSON.parse(sessionStorage.getItem('currentUser') || 'null');
    if (!usuarioLogueado) {

      alert('No se ha encontrado un usuario logueado');
      this.router.navigate(['/inicio']);
      return;
    }
    this.usuario = usuarioLogueado;


    this.apiCrud.getProfes().subscribe((profesores) => {
      this.profesores = profesores;
    });

    this.apiCrud.getUsuarios().subscribe((usuarios) => {
      this.asignaturas = usuarios.reduce((acc, usuario: any) => {
        return acc.concat(usuario.clasesRegistradas || []);
      }, []);
    });
  }

  enviarJustificacion() {
    if (!this.asignaturaSeleccionada || !this.profesorSeleccionado || !this.fechaJustificacion || !this.motivoJustificacion) {
      alert('Todos los campos son obligatorios');
      return;
    }

    const nuevaJustificacion = {
      idJustificacion: new Date().getTime(),  
      idUsuario: this.usuario.id,
      idProfesor: this.profesorSeleccionado,
      asignatura: this.asignaturaSeleccionada,
      fecha: this.fechaJustificacion,
      motivo: this.motivoJustificacion,
      comentarioDocente: '' 
    };

    this.usuario.justificaciones.push(nuevaJustificacion);
    this.apiCrud.actualizarUsuario(this.usuario).subscribe((respuesta) => {
      console.log('Justificación guardada en el usuario');
    });

    const profesorSeleccionado = this.profesores.find(profesor => profesor.id === this.profesorSeleccionado);
    if (profesorSeleccionado) {
      profesorSeleccionado.justificaciones.push(nuevaJustificacion);
      this.apiCrud.actualizarProfesor(profesorSeleccionado).subscribe((respuesta) => {
        console.log('Justificación guardada en el profesor');
      });
    }

    alert('Justificación enviada con éxito');
    this.router.navigate(['/inicio']);  
  }
}
