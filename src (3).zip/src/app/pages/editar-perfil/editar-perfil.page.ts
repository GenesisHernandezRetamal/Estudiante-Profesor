import { Component, OnInit } from '@angular/core';
import { ApiusersService } from 'src/app/services/apiusers.service';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { AuthserviceService } from 'src/app/services/auth.service';


@Component({
  selector: 'app-editar-perfil',
  templateUrl: './editar-perfil.page.html',
  styleUrls: ['./editar-perfil.page.scss'],
})
export class EditarPerfilPage implements OnInit {
  usuario = {
    id: '',
    username: '',
    email: '',
    password: '',
    rut: ''
  };

  constructor(
    private apiuser: ApiusersService,
    private router: Router,
    private alertController: AlertController,
    private authService: AuthserviceService 
  ) {}

  ngOnInit() {
    this.cargarUsuario();
  }

  cargarUsuario() {
    const currentUser = this.authService.getCurrentUser();

    if (currentUser) {
      this.usuario = {
        id: currentUser.id,
        username: currentUser.username,
        email: currentUser.email,
        password: '', // Mantén la contraseña vacía por razones de seguridad
        rut: currentUser.rut
      };
    } else {
      this.router.navigate(['/login']); // Redirigir al inicio de sesión si no hay usuario autenticado
    }
  }

  async editarPerfil() {
    const confirmAlert = await this.alertController.create({
      header: 'Confirmar',
      message: '¿Estás seguro de que deseas actualizar tu perfil?',
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel'
        },
        {
          text: 'Confirmar',
          handler: () => {
            this.apiuser.putUsuarios(this.usuario).subscribe(
              async response => {
                const alert = await this.alertController.create({
                  header: 'Perfil actualizado',
                  message: 'Los cambios en el perfil se han guardado correctamente.',
                  buttons: ['OK']
                });
                await alert.present();
                this.router.navigate(['/perfil']); // Redirigir al perfil después de editar
              },
              async error => {
                const alert = await this.alertController.create({
                  header: 'Error',
                  message: 'Hubo un problema al actualizar el perfil.',
                  buttons: ['OK']
                });
                await alert.present();
              }
            );
          }
        }
      ]
    });
    await confirmAlert.present();
  }
}
