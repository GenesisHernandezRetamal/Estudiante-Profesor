import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApicrudService } from '../../services/apicrud.service';


@Component({
  selector: 'app-crear-usuario',
  templateUrl: './crear-usuario.page.html',
  styleUrls: ['./crear-usuario.page.scss'],
})
export class CrearUsuarioPage {
  usuarioForm: FormGroup;

  constructor(private formBuilder: FormBuilder, private apiCrudService: ApicrudService) {
    // Inicializa el formulario con validaciones
    this.usuarioForm = this.formBuilder.group({
      username: ['', [Validators.required, Validators.minLength(3)]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      email: ['', [Validators.required, Validators.email]],
      rut: ['', [Validators.required]],
      isactive: [true], // Por defecto, el usuario está activo
    });
  }

  crearUsuario() {
    if (this.usuarioForm.valid) {
      const nuevoUsuario = this.usuarioForm.value;

      const usuarioConDetalles = {
        ...nuevoUsuario,
        id: Date.now().toString(), 
        justificaciones: [],  
        clasesRegistradas: []    
      };

      this.apiCrudService.agregarUsuario(usuarioConDetalles).subscribe({
        next: () => {
          console.log('Usuario creado con éxito');
          this.usuarioForm.reset(); // Reinicia el formulario
        },
        error: (err) => {
          console.error('Error al crear el usuario:', err);
        }
      });
    }
  }
}
