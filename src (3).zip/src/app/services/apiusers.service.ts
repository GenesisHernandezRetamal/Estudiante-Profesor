import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Users } from 'src/interfaces/users';
import { environment } from 'src/environments/environment';
import { switchMap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ApiusersService {
  private currentUser: any;
  private userApiUrl = 'http://localhost:3000/usuarios';
  private apiUrl = 'http://localhost:3000/usuarios';

  constructor(private http: HttpClient) {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser') || 'null');
   }

   getCurrentUser() {
    return this.currentUser;
  }
  getUserByUsername(username: string): Observable<Users> {
      return this.http.get<Users>(`${this.userApiUrl}/${username}`);
  }

  putUsuarios(usuario: any): Observable<any> {
    return this.http.put(`${this.userApiUrl}/${usuario.id}`, this.getUserByUsername);
  }

  getUsuario(id: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/${id}`);
  } 


  agregarClaseRegistrada(idUsuario: string, registro: any): Observable<any> {
    return this.getUsuario(idUsuario).pipe(
      switchMap(usuario => {
        usuario.clasesRegistradas = usuario.clasesRegistradas || [];  
        usuario.clasesRegistradas.push(registro);  
        return this.http.put(`${this.apiUrl}/${idUsuario}`, usuario);  
      })
    );
  }
}
