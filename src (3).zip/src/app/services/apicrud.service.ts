import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Users } from 'src/interfaces/users';
import { map } from 'rxjs';
import { catchError,throwError } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ApicrudService {

  private apiUrl2 = 'http://localhost:3000';
  private apiUrl = 'http://localhost:3000/usuarios'; 
  private apiUrlProfesores = 'http://localhost:3000/profes'; 

  constructor(private http: HttpClient) {}

  agregarUsuario(nuevoUsuario: any) {
    return this.http.post(this.apiUrl, nuevoUsuario);
  }

  crearJustificacion(data: any): Observable<any> {
    return this.http.post(`${this.apiUrl2}/usuarios${data.idUsuario}/justificaciones`, data);

  }

  // Obtener justificaciones por asignatura para el profesor
  obtenerJustificaciones(idProfesor: string, asignatura: string): Observable<any> {
    return this.http.get(`${this.apiUrl2}/profes${idProfesor}/justificaciones?asignatura=${asignatura}`);
  }


  getUsuarios(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl2}/usuarios`);
  }

  // Obtener todos los profesores
  getProfes(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl2}/profes`);
  }

  actualizarUsuario(usuario: any): Observable<any> {
    return this.http.put<any>(`${environment.urlApi}usuarios/${usuario.id}`, usuario);
  }
  
  // Método para actualizar los datos del profesor
  actualizarProfesor(profesor: any): Observable<any> {
    return this.http.put<any>(`${environment.urlApi}profes/${profesor.id}`, profesor);
  }
  getJustificacionesDeUsuario(idUsuario: string): Observable<any[]> {
    return this.http.get<Users[]>(`${environment.urlApi}usuarios/?id=${idUsuario}`).pipe(
      map((usuarios: Users[]) => {
        const usuario = usuarios.find(u => u.id === idUsuario); // Encuentra al usuario logueado
        return usuario ? usuario.justificaciones : []; // Devuelve las justificaciones del usuario
      }),
      catchError(error => {
        return throwError(() => new Error('No se pudieron cargar las justificaciones.'));
      })
    );
}
}
