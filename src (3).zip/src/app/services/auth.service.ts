import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, throwError } from 'rxjs';
import { Users, UserNuevo } from 'src/interfaces/users';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
import { tap } from 'rxjs/operators'; 

@Injectable({
  providedIn: 'root'
})
export class AuthserviceService {
  private currentUser: any;
  private usuarios = JSON.parse(localStorage.getItem('usuarios') || '[]');

  constructor(private httpclient: HttpClient, private router: Router) { 
    this.currentUser = JSON.parse(sessionStorage.getItem('currentUser') || 'null');
  }

  IsLoggedIn(): boolean {
    return !!sessionStorage.getItem('currentUser');
  }

  getCurrentUser() {
    return this.currentUser;
  }

  login(username: string, password: string): Observable<any> {
    return this.httpclient.get<Users[]>(`${environment.urlApi}usuarios/?username=${username}`).pipe(
      catchError(error => {
        return throwError(() => new Error('Usuario no encontrado.'));
      }),
      tap((usuarios: Users[]) => {  
        const usuario = usuarios.find((u: Users) => u.username === username && u.password === password);
        if (usuario) {

          sessionStorage.setItem('currentUser', JSON.stringify(usuario));
          sessionStorage.setItem('username', usuario.username); 
        } else {
          throw new Error('Credenciales incorrectas');
        }
      })
    );
  }

  logout() {
    sessionStorage.removeItem('username'); 
    sessionStorage.removeItem('currentUser');  
    this.router.navigate(['/inicio']).then(() => {
      window.location.reload();
    });
  }


  GetAllUsers(): Observable<Users[]> {
    return this.httpclient.get<Users[]>(`${environment.urlApi}usuarios`);
  }

  GetUserByUsername(username: string): Observable<Users[]> {
    return this.httpclient.get<Users[]>(`${environment.urlApi}usuarios/?username=${username}`);
  }


  PostUsuario(userNuevo: UserNuevo): Observable<UserNuevo> {
    const newUser = {
      ...userNuevo,
      id: Date.now().toString(),
      isactive: true,
      justificaciones: [],
      clasesRegistradas: []
    };
    return this.httpclient.post<UserNuevo>(`${environment.urlApi}usuarios`, newUser);
  }

  updateUser(user: Users): Observable<Users> {
    const url = `${environment.urlApi}usuarios/${user.id}`;
    return this.httpclient.put<Users>(url, user);
  }

  handleError(error: any) {
    return throwError(() => new Error(error.message));
  }
  getLoggedInUserId(): string | null {

    return localStorage.getItem('userId');
  }
  getLoggedUser(username: string): Observable<Users> {
    return this.httpclient.get<Users>(`${environment.urlApi}usuarios/${username}`);
  }
  
  getProfessorData(profesorId: string): Observable<any> {
    return this.httpclient.get<any>(`${environment.urlApi}/profes/${profesorId}`);
  }
}
