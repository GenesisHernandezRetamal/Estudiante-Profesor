import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApidatosService {
  private apiUrl = 'http://localhost:3000/asignaturas';
  private urlAp = 'http://localhost:3000/justificaciones';

  // URLs de usuarios y profesores
  private usuariosUrl = 'http://localhost:3000/usuarios';
  private profesUrl = 'http://localhost:3000/profes';

  constructor(private http: HttpClient) {}
  updateUsuario(usuarioId: string, usuario: any): Observable<any> {
    return this.http.put(`${this.usuariosUrl}/${usuarioId}`, usuario);
  }

  // Métodos para obtener datos
  getUsuario(id: string): Observable<any> {
    return this.http.get<any>(`${this.usuariosUrl}/${id}`);
  }

  getAsignaturas(): Observable<any> {
    return this.http.get(this.apiUrl);
  }

  getJustificaciones(): Observable<any> {
    return this.http.get(this.urlAp);
  }

  getUsuarios(): Observable<any> {
    return this.http.get(this.usuariosUrl);
  }

  getProfesores(): Observable<any[]> {
    return this.http.get<any[]>(this.profesUrl);
  }

  // Método para agregar una justificación tanto al usuario como al profesor
  addJustificacion(justificacion: any) {
    const usuarioId = justificacion.idUsuario;
    const profesorId = justificacion.idProfesor;

    // Actualizar el usuario
    this.getUsuarios().subscribe((usuarios: any[]) => {
      const usuario = usuarios.find(u => u.id === usuarioId);
      if (usuario) {
        if (!usuario.justificaciones) {
          usuario.justificaciones = [];
        }
        usuario.justificaciones.push(justificacion);

        // Actualizar usuario en el backend
        this.http.put(`${this.usuariosUrl}/${usuarioId}`, usuario).subscribe(
          () => {
            console.log('Justificación agregada al usuario.');
          },
          (error) => {
            console.error('Error al actualizar el usuario:', error);
          }
        );
      }
    });

    // Actualizar el profesor
    this.getProfesores().subscribe((profesores: any[]) => {
      const profesor = profesores.find(p => p.id === profesorId);
      if (profesor) {
        if (!profesor.justificaciones) {
          profesor.justificaciones = [];
        }
        profesor.justificaciones.push(justificacion);

        // Actualizar profesor en el backend
        this.http.put(`${this.profesUrl}/${profesorId}`, profesor).subscribe(
          () => {
            console.log('Justificación agregada al profesor.');
          },
          (error) => {
            console.error('Error al actualizar el profesor:', error);
          }
        );
      }
    });
  }

  // Método para agregar un nuevo usuario
  addUsuario(usuario: any): Observable<any> {
    return this.http.post(this.usuariosUrl, usuario);
  }

  // Obtener usuario por ID
  getUsuarioById(idUsuario: string): Observable<any> {
    return this.http.get(`${this.usuariosUrl}/${idUsuario}`);
  }
}
