import { Component } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { register } from 'swiper/element/bundle';
register();


  
interface Opciones{
  icon:string;
  name:string;
  redirecTo: string;
}


@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  opciones: Opciones[]=[
    {
      icon: 'person-outline',
      name: 'Iniciar Sesión',
      redirecTo: '/inicio-ses'
    },
    {
      icon: 'person-add-outline',
      name: 'Registro',
      redirecTo: '/crear-usuario'
    },
    {
      icon: 'person-circle-outline',
      name: 'Ver Perfil',
      redirecTo: '/ver-perfil'
    },
    {
      icon: 'reader-outline',
      name: 'Registro Asistencia',
      redirecTo: '/registro-clases'
    },
    {
      icon: 'receipt-outline',
      name: 'Justificar Inasistencia',
      redirecTo: '/justificacion'
    },

    {
      name: 'Ver Justificacion',
      redirecTo: '/ver-justificaciones',
      icon: ''
    },
    

  ]
  

  constructor(private menuController: MenuController) { }
  cerrarMenu() {
    this.menuController.close('first')
  }
  }

  

