
export interface Docente {
  id: string;
  username: string;
  email: string;
  password: string;
  rut: string;
  fotitoUrl?: string;
  isactive: boolean;
  perfil: {
    titulo: string;
    descripcion: string;
    foto?: string;
  };
  justificaciones: {
    idJustificacion: number;
    estudiante: string;
    asignatura: string;
    fecha: string;
    motivo: string;
    comentarioDocente: string;
  }[];
  qrEscaneados: {
    idClase: number;
    asignatura: string;
    fecha: string;
    datosQR: string;
  }[];
  asistencias: {
    idClase: number;
    asignatura: string;
    fecha: string;
    estudiantesAsistentes: {
      nombre: string;
      notificacionEnviada: boolean;
    }[];
  }[];
}

export interface DocenteNuevo {
  username: string;
  email: string;
  password: string;
  rut: string;
  fotitoUrl?: string;
  isactive: boolean;
  perfil: {
    titulo: string;
    descripcion: string;
    foto?: string;
  };
}
export interface Asignatura {
  idAsignatura: string;
  nombre: string;
  fecha: string;
  profesor: string;
  qrData: string;
}

export interface Justificacion {
  idJustificacion: string;
  idUsuario: string;
  idProfesor: string;
  asignatura: Asignatura;
  fecha: string;
  motivo: string;
  comentarioDocente: string;
  nuevoComentario?: string;  // Esto podría ser para manejar los comentarios que el profesor agregue
}

export interface Justificacion {
  idJustificacion: string;
  idUsuario: string;
  idProfesor: string;
  asignatura: Asignatura;
  fecha: string;
  motivo: string;
  comentarioDocente: string;
  nuevoComentario?: string;  // Esto podría ser para manejar los comentarios que el profesor agregue
}



