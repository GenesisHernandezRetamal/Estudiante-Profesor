
export interface Users{
    id:string;
    username:string;
    email:string;
    password:string;
    rut:string;
    fotitoUrl?: string;
    isactive:boolean;
}

export interface UserNuevo{
    username:string;
    email:string;
    password:string;
    rut:string;
    fotitoUrl?: string;
    isactive: boolean;
}


