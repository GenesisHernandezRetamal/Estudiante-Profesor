import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { ApiusersService } from './apiusers.service';

@Injectable({
  providedIn: 'root'
})
export class JustificacionesService {
  private justificaciones = [
    {
      idJustificacion: 1732223427743,
      idUsuario: "2",
      idProfesor: "1",
      asignatura: "Arquitectura",
      fecha: "2024-11-21T21:10:27.743Z",
      motivo: "toi comiendo completos",
      comentarioDocente: ""
    },
    // Agrega más justificaciones si es necesario
  ];

  constructor(private http: HttpClient) {}

  // Método para obtener las justificaciones (simulado)
  obtenerJustificaciones(): Observable<any[]> {
    return of(this.justificaciones); // Aquí simulamos la obtención de los datos
  }

  // Método para guardar el comentario y enviarlo al servidor


  guardarComentario(justificacion: any): Observable<any> {
    const url = 'http://localhost:3000/profes/justificaciones'; // La URL de tu API

    // Realiza una solicitud POST para guardar la justificación con el comentario
    return this.http.post(url, justificacion);
  }
}
