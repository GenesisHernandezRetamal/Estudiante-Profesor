import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { switchMap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ApidatosService {
  private usuariosUrl = 'http://localhost:3000/usuarios';
  private profesUrl = 'http://localhost:3000/profes';
  private asignaturasUrl = 'http://localhost:3000/asignaturas';

  constructor(private http: HttpClient) {}


  addProfesor(profesor: any): Observable<any> {
    return this.http.post(this.profesUrl, profesor);
  }
  
  // Obtener usuarios
  getUsuarios(): Observable<any[]> {
    return this.http.get<any[]>(this.usuariosUrl);
  }

  // Obtener profesores
  getProfesores(): Observable<any[]> {
    return this.http.get<any[]>(this.profesUrl);
  }

  // Obtener asignaturas
  getAsignaturas(): Observable<any[]> {
    return this.http.get<any[]>(this.asignaturasUrl);
  }

  // Obtener un usuario por ID
  getUsuarioById(id: string): Observable<any> {
    return this.http.get<any>(`${this.usuariosUrl}/${id}`);
  }

  // Obtener un profesor por ID
  getProfesorById(id: string): Observable<any> {
    return this.http.get<any>(`${this.profesUrl}/${id}`);
  }

  // Agregar una justificación al usuario y al profesor
  addJustificacion(justificacion: any): void {
    const { idUsuario, idProfesor } = justificacion;

    // Agregar justificación al usuario
    this.getUsuarioById(idUsuario).subscribe(usuario => {
      if (!usuario.justificaciones) {
        usuario.justificaciones = [];
      }
      usuario.justificaciones.push(justificacion);

      // Actualizar el usuario en el backend
      this.http.put(`${this.usuariosUrl}/${idUsuario}`, usuario).subscribe(
        () => console.log('Justificación agregada al usuario'),
        (error) => console.error('Error al agregar justificación al usuario:', error)
      );
    });

    // Agregar justificación al profesor
    this.getProfesorById(idProfesor).subscribe(profesor => {
      if (!profesor.justificaciones) {
        profesor.justificaciones = [];
      }
      profesor.justificaciones.push(justificacion);

      // Actualizar el profesor en el backend
      this.http.put(`${this.profesUrl}/${idProfesor}`, profesor).subscribe(
        () => console.log('Justificación agregada al profesor'),
        (error) => console.error('Error al agregar justificación al profesor:', error)
      );
    });
  }

  // Actualizar comentario en una justificación (profesor y usuario)
  actualizarComentarioJustificacion(profesorId: string, justificacion: any): Observable<any> {
    return this.getProfesores().pipe(
      switchMap((profesores: any[]) => {
        const profesor = profesores.find(p => p.id === profesorId);
        if (profesor) {
          const justificacionExistente = profesor.justificaciones.find(
            (j: any) => j.idJustificacion === justificacion.idJustificacion
          );
          if (justificacionExistente) {
            justificacionExistente.comentarioDocente = justificacion.comentarioDocente;

            // Actualizar el profesor en el backend
            return this.http.put(`${this.profesUrl}/${profesorId}`, profesor);
          }
        }
        throw new Error('Justificación no encontrada en el profesor');
      }),
      switchMap(() => {
        const usuarioId = justificacion.idUsuario;
        return this.getUsuarios().pipe(
          switchMap((usuarios: any[]) => {
            const usuario = usuarios.find(u => u.id === usuarioId);
            if (usuario) {
              const justificacionUsuario = usuario.justificaciones.find(
                (j: any) => j.idJustificacion === justificacion.idJustificacion
              );
              if (justificacionUsuario) {
                justificacionUsuario.comentarioDocente = justificacion.comentarioDocente;

                // Actualizar el usuario en el backend
                return this.http.put(`${this.usuariosUrl}/${usuarioId}`, usuario);
              }
            }
            throw new Error('Justificación no encontrada en el usuario');
          })
        );
      })
    );
  }
}
