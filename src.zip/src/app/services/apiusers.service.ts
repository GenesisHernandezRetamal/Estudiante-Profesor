import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ApiusersService {
  private apiUrl2 = 'http://localhost:3000';
  

  constructor(private http: HttpClient) {}

  agregarComentario(idJustificacion: number, comentario: string): Observable<any> {
    return this.http.put(`http://localhost:3000/justificaciones/${idJustificacion}`, { comentarioDocente: comentario });
  }
  actualizarUsuario(usuario: any): Observable<any> {
    return this.http.put(`${this.apiUrl2}/usuarios/${usuario.id}`, usuario);
  }
  getUsuarios(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl2}/usuarios`);
  }
  
  getProfes(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl2}/profes`);
  }
  
  getJustificaciones(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl2}/justificaciones`);
  }

  getAsignaturas(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl2}/asignaturas`);
  }

  actualizarJustificacionProfesor(idProfesor: string, idJustificacion: string, justificacion: any): Observable<any> {
    const url = `${this.apiUrl2}/profes/${idProfesor}/justificaciones/${idJustificacion}`;
    return this.http.put(url, justificacion);
  }

actualizarJustificacionUsuario(justificacion: any): Observable<any> {
  const url = `${this.apiUrl2}/usuarios/${justificacion.idUsuario}/justificaciones/${justificacion.idJustificacion}`;
  return this.http.put(url, justificacion);
}


  
    
  
  
  
  
  
}
