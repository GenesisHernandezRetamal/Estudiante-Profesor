import { Component } from "@angular/core";
import { ApidatosService } from "src/app/services/apidatos.service";

@Component({
  selector: 'app-registro',
  templateUrl: './registro.page.html',
  styleUrls: ['./registro.page.scss'],
})

export class RegistroPage {
  username: string = '';
  email: string = '';
  password: string = '';
  rut: string = '';
  tituloPerfil: string = '';
  descripcionPerfil: string = '';
  fotoUrl: string = '';
  asignaturaNombre: string = '';
  asignaturaSeccion: string = '';
  asignaturaDescripcion: string = '';

  constructor(private apidatosService: ApidatosService) {}

  registerProfesor() {
    const nuevoProfesor = {
      id: new Date().getTime().toString(), // Generar un ID único
      username: this.username,
      email: this.email,
      password: this.password,
      rut: this.rut,
      isactive: true,
      fotitoUrl: this.fotoUrl,
      perfil: {
        titulo: this.tituloPerfil,
        descripcion: this.descripcionPerfil,
        foto: this.fotoUrl || '',
      },
      justificaciones: [],
      asignaturas: [
        {
          id: new Date().getTime().toString(), // ID único para la asignatura
          nombre: this.asignaturaNombre,
          seccion: this.asignaturaSeccion,
          descripcion: this.asignaturaDescripcion,
        },
      ],
    };

    this.apidatosService.addProfesor(nuevoProfesor).subscribe(
      () => {
        alert('¡Profesor registrado exitosamente!');
      },
      (error) => {
        console.error('Error al registrar el profesor:', error);
        alert('Hubo un error al registrar el profesor.');
      }
    );
  }
}

