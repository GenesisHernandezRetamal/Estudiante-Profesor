import { Component, OnInit } from '@angular/core';
import { ApiusersService } from 'src/app/services/apiusers.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-justificaciones',
  templateUrl: './justificaciones.page.html',
  styleUrls: ['./justificaciones.page.scss'],
})
export class JustificacionesPage implements OnInit {
  justificaciones: any[] = []; 
  constructor(private apiuser: ApiusersService, private router: Router) {}

  ngOnInit() {
    this.cargarJustificaciones();  
  }

  cargarJustificaciones() {
    const justificacionesCombinadas: any[] = [];

  
    this.apiuser.getUsuarios().subscribe({
      next: (usuarios) => {
        usuarios.forEach((usuario: any) => {
          if (usuario.justificaciones) {
            justificacionesCombinadas.push(...usuario.justificaciones);
          }
        });

        
        this.apiuser.getProfes().subscribe({
          next: (profes) => {
            profes.forEach((profe: any) => {
              if (profe.justificaciones) {
                justificacionesCombinadas.push(...profe.justificaciones);
              }
            });

            
            this.justificaciones = justificacionesCombinadas;
            console.log('Todas las justificaciones:', this.justificaciones);
          },
          error: (err) => {
            console.error('Error al cargar justificaciones de profesores:', err);
          },
        });
      },
      error: (err) => {
        console.error('Error al cargar justificaciones de usuarios:', err);
      },
    });
  }
}
