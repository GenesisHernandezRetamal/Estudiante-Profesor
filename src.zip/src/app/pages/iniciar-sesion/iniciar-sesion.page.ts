import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';
import { ToastController } from '@ionic/angular';
import { Docente } from 'src/interfaces/docente';
import { AlertController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-iniciar-sesion',
  templateUrl: './iniciar-sesion.page.html',
  styleUrls: ['./iniciar-sesion.page.scss'],
})
export class IniciarSesionPage implements OnInit {

  loginForm: FormGroup;
  docenteData: Docente | null = null;

  constructor(
    private authservice: AuthService,
    private router: Router,
    private toast: ToastController,
    private alertController: AlertController,
    private builder: FormBuilder
  ) {
    this.loginForm = this.builder.group({
      username: new FormControl('', [Validators.required, Validators.minLength(6)]),
      password: new FormControl('', [Validators.required, Validators.minLength(8)]),
    });
  }

  ngOnInit() {}

  login() {
    if (!this.loginForm.valid) {
      return;
    }

    const username = this.loginForm.value.username;
    const password = this.loginForm.value.password;

    this.authservice.GetDocenteByUsername(username).subscribe((resp: Docente[]) => {
      if (resp.length === 0) {
        this.loginForm.reset();
        this.showAlert('No existe...', 'El usuario no está registrado como docente.');
        return;
      }

      this.docenteData = resp[0];

      if (this.docenteData.password !== password) {
        this.loginForm.reset();
        this.showAlert('Error', 'La contraseña es incorrecta.');
        return;
      }

      if (!this.docenteData.isactive) {
        this.loginForm.reset();
        this.showAlert('Usuario inactivo', 'Por favor, contacte al administrador.');
        return;
      }

      this.IniciarSesion(this.docenteData);
    });
  }

  private IniciarSesion(docente: Docente) {
   
    sessionStorage.setItem('docenteUsername', docente.username);
    sessionStorage.setItem('docenteId', docente.id);

    
    this.showToast(`Bienvenido, ${docente.username}`);
    this.router.navigate(['/inicio']); 
  }

  private async showToast(message: string) {
    const toast = await this.toast.create({
      message,
      duration: 3000,
    });
    toast.present();
  }

  private async showAlert(header: string, message: string) {
    const alert = await this.alertController.create({
      header,
      message,
      buttons: ['OK'],
    });
    alert.present();
  }

  Registrar() {
    this.router.navigate(['/crear-docente']);
  }
}
